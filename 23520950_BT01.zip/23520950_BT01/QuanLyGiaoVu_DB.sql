CREATE DATABASE QuanLyGiaoVu
USE QuanLyGiaoVu
CREATE TABLE dbo.KHOA(
    MAKHOA varchar(4) NOT NULL,
    TENKHOA varchar(40),
    NGTLAP smalldatetime,
    TRGKHOA char(4)
)
ALTER TABLE dbo.KHOA ADD CONSTRAINT PK_KHOA PRIMARY KEY (MAKHOA)

CREATE TABLE dbo.MONHOC(
    MAMH varchar(10) NOT NULL,
    TENMH varchar(40),
    TCLT tinyint ,
    TCTH tinyint ,
    MAKHOA varchar(4) 
)
ALTER TABLE dbo.MONHOC ADD CONSTRAINT PK_MONHOC PRIMARY KEY (MAMH)

CREATE TABLE dbo.DIEUKIEN(
    MAMH varchar(10) NOT NULL,
    MAMH_TRUOC varchar(10) NOT NULL
) 
ALTER TABLE dbo.DIEUKIEN ADD CONSTRAINT PK_DIEUKIEN PRIMARY KEY (MAMH,MAMH_TRUOC)

CREATE TABLE dbo.GIAOVIEN(
    MAGV char(4) NOT NULL,
    HOTEN varchar(40),
    HOCVI varchar(10),
    HOCHAM varchar(10) ,
    GIOITINH varchar(3) ,
    NGSINH smalldatetime ,
    NGVL smalldatetime ,
    HESO numeric(4,2),
    MUCLUONG money,
    MAKHOA varchar(4)
)
ALTER TABLE dbo.GIAOVIEN ADD CONSTRAINT PK_GIAOVIEN PRIMARY KEY (MAGV)

CREATE TABLE dbo.LOP(
    MALOP char(3) NOT NULL,
    TENLOP varchar(40) ,
    TRGLOP char(5) ,
    SISO tinyint ,
    MAGVCN char(4),
    MAKHOA varchar(4)
)
ALTER TABLE dbo.LOP ADD CONSTRAINT PK_LOP PRIMARY KEY (MALOP)

CREATE TABLE dbo.HOCVIEN(
    MAHV char(5) NOT NULL,
    HO varchar(40),
    TEN varchar(10),
    NGSINH smalldatetime,
    GIOITINH varchar(3),
    NOISINH varchar(40),
    MALOP char(3)
)
ALTER TABLE dbo.HOCVIEN ADD CONSTRAINT PK_HOCVIEN PRIMARY KEY (MAHV)

CREATE TABLE dbo.GIANGDAY(
    MALOP char(3) NOT NULL,
    MAMH varchar(10) NOT NULL,
    MAGV char(4) ,
    HOCKY tinyint ,
    NAM smallint,
    TUNGAY smalldatetime,
    DENNGAY smalldatetime
)
ALTER TABLE dbo.GIANGDAY ADD CONSTRAINT PK_GIANGDAY PRIMARY KEY (MALOP,MAMH)

CREATE TABLE dbo.KETQUATHI(
    MAHV char(5) NOT NULL,
    MAMH varchar(10) NOT NULL,
    LANTHI tinyint NOT NULL,
    NGTHI smalldatetime ,
    DIEM numeric(4,2),
    KQUA varchar(10)
)
ALTER TABLE dbo.KETQUATHI ADD CONSTRAINT PK_KETQUATHI PRIMARY KEY (MAHV,MAMH,LANTHI)

ALTER TABLE dbo.HOCVIEN ADD CONSTRAINT FK_HOCVIEN_LOP FOREIGN KEY (MALOP) REFERENCES dbo.LOP(MALOP)
ALTER TABLE dbo.LOP ADD CONSTRAINT FK_LOP_KHOA FOREIGN KEY (MAKHOA) REFERENCES dbo.KHOA(MAKHOA)
ALTER TABLE dbo.LOP ADD CONSTRAINT FK_LOP_HOCVIEN FOREIGN KEY (TRGLOP) REFERENCES dbo.HOCVIEN(MAHV)
ALTER TABLE dbo.KETQUATHI ADD CONSTRAINT FK_KETQUATHI_HOCVIEN FOREIGN KEY (MAHV) REFERENCES dbo.HOCVIEN(MAHV)
ALTER TABLE dbo.KETQUATHI ADD CONSTRAINT FK_KETQUATHI_MONHOC FOREIGN KEY (MAMH) REFERENCES dbo.MONHOC(MAMH)
ALTER TABLE dbo.MONHOC ADD CONSTRAINT FK_MONHOC_KHOA FOREIGN KEY (MAKHOA) REFERENCES dbo.KHOA (MAKHOA)
ALTER TABLE dbo.GIAOVIEN ADD CONSTRAINT FK_GIAOVIEN_KHOA FOREIGN KEY (MAKHOA) REFERENCES dbo.KHOA (MAKHOA)
ALTER TABLE dbo.KHOA ADD CONSTRAINT FK_KHOA_GIAOVIEN FOREIGN KEY (TRGKHOA) REFERENCES dbo.GIAOVIEN (MAGV)
ALTER TABLE dbo.GIANGDAY ADD CONSTRAINT FK_GIANGDAY_LOP FOREIGN KEY (MALOP) REFERENCES dbo.LOP (MALOP)
ALTER TABLE dbo.GIANGDAY ADD CONSTRAINT FK_GIANGDAY_GIAOVIEN FOREIGN KEY (MAGV) REFERENCES dbo.GIAOVIEN (MAGV)
ALTER TABLE dbo.GIANGDAY ADD CONSTRAINT FK_GIANGDAY_MONHOC FOREIGN KEY (MAMH) REFERENCES dbo.MONHOC (MAMH)


INSERT INTO dbo.DIEUKIEN (MAMH, MAMH_TRUOC)
VALUES
    ('CSDL','CTRR'),
    ('CSDL', 'CTDLGT'),
    ('CTDLGT', 'THDC'),
    ('PTTKTT', 'THDC'),
    ('PTTKTT', 'CTDLGT'),
    ('DHMT', 'THDC'),
    ('LTHDT', 'THDC'),
    ('PTTKHTTT', 'CSDL')
INSERT INTO dbo.LOP (MALOP, TENLOP, TRGLOP, SISO, MAGVCN,MAKHOA)
VALUES
    ('K11', 'Lop 1 khoa 1', null, 11, 'GV07',null),
    ('K12', 'Lop 2 khoa 1', null, 12, 'GV09',null),
    ('K13', 'Lop 3 khoa 1', null, 12, 'GV14',null)
INSERT INTO dbo.HOCVIEN (MAHV, HO, TEN, NGSINH, GIOITINH, NOISINH, MALOP)
VALUES
    ('K1101', 'Nguyen Van', 'A', '1986-01-27', 'Nam', 'TpHCM', 'K11'),
    ('K1102', 'Tran Ngoc', 'Han', '1986-03-14', 'Nu', 'Kien Giang', 'K11'),
    ('K1103', 'Ha Duy', 'Lap', '1986-04-18', 'Nam', 'Nghe An', 'K11'),
    ('K1104', 'Tran Ngoc', 'Linh', '1986-03-30', 'Nu', 'Tay Ninh', 'K11'),
    ('K1105', 'Tran Minh', 'Long', '1986-12-27', 'Nam', 'TpHCM', 'K11'),
    ('K1106', 'Le Nhat', 'Minh', '1986-01-24', 'Nam', 'TpHCM', 'K11'),
    ('K1107', 'Nguyen Nhu', 'Nhut', '1986-01-27', 'Nam', 'Ha Noi', 'K11'),
    ('K1108', 'Nguyen Manh', 'Tam', '1986-12- 27', 'Nam', 'Kien Giang', 'K11'),
    ('K1109', 'Phan Thi Thanh', 'Tam', '1986-01-27', 'Nu', 'Vinh Long', 'K11'),
    ('K1110', 'Le Hoai', 'Thuong', '1986-02-05', 'Nu', 'Can Tho', 'K11'),
    ('K1111', 'Le Ha', 'Vinh', '1986-12-25', 'Nam', 'Vinh Long', 'K11'),
    ('K1201', 'Nguyen Van', 'B', '1986-12-11', 'Nam', 'TpHCM', 'K12'),
    ('K1202', 'Nguyen Thi Kim', 'Duyen', '1986-01-18', 'Nu', 'TpHCM', 'K12'),
    ('K1203', 'Tran Thi Kim', 'Duyen', '1986-09-17', 'Nu', 'TpHCM', 'K12'),
    ('K1204', 'Truong My', 'Hanh', '1986-05-19', 'Nu', 'Dong Nai', 'K12'),
    ('K1205', 'Nguyen Thanh', 'Nam', '1986-04-17', 'Nam', 'TpHCM', 'K12'),
    ('K1206', 'Nguyen Thi Truc', 'Thanh', '1986-03-04', 'Nu', 'Kien Giang', 'K12'),
    ('K1207', 'Tran Thi Bich', 'Thuy', '1986-02-08', 'Nu', 'Nghe An', 'K12'),
    ('K1208', 'Huynh Thi Kim', 'Trieu', '1986-04-08', 'Nu', 'Tay Ninh', 'K12'),
    ('K1209', 'Pham Thanh', 'Trieu', '1986-02-23', 'Nam', 'TpHCM', 'K12'),
    ('K1210', 'Ngo Thanh', 'Tuan', '1986-02-14', 'Nam', 'TpHCM', 'K12'),
    ('K1211', 'Do Thi', 'Xuan', '1986-03-09', 'Nu', 'Ha Noi', 'K12'),
    ('K1212', 'Le Thi Phi', 'Yen', '1986-03-12', 'Nu', 'TpHCM', 'K12'),
    ('K1301', 'Nguyen Thi Kim', 'Cuc', '1986-06-09', 'Nu', 'Kien Giang', 'K13'),
    ('K1302', 'Truong Thi My', 'Hien', '1986-03-18', 'Nu', 'Nghe An', 'K13'),
    ('K1303', 'Le Duc', 'Hien', '1986-03-21', 'Nam', 'Tay Ninh', 'K13'),
    ('K1304', 'Le Quang', 'Hien', '1986-04-18', 'Nam', 'TpHCM', 'K13'),
    ('K1305', 'Le Thi', 'Huong', '1986-03-27', 'Nu', 'TpHCM', 'K13'),
    ('K1306', 'Nguyen Thai', 'Huu', '1986-03-30', 'Nam', 'Ha Noi', 'K13'),
    ('K1307', 'Tran Minh', 'Man', '1986-05-28', 'Nam', 'TpHCM', 'K13'),
    ('K1308', 'Nguyen Hieu', 'Nghia', '1986-04-08', 'Nam', 'Kien Giang', 'K13'),
    ('K1309', 'Nguyen Trung', 'Nghia', '1987-01-18', 'Nam', 'Nghe An', 'K13'),
    ('K1310', 'Tran Thi Hong', 'Tham', '1986-04-22', 'Nu', 'Tay Ninh', 'K13'),
    ('K1311', 'Tran Minh', 'Thuc', '1986-04-04', 'Nam', 'TpHCM', 'K13'),
    ('K1312', 'Nguyen Thi Kim', 'Yen', '1986-09-07', 'Nu', 'TpHCM', 'K13')
UPDATE dbo.LOP SET TRGLOP='K1108' WHERE MALOP='K11'
UPDATE dbo.LOP SET TRGLOP='K1205' WHERE MALOP='K12'
UPDATE dbo.LOP SET TRGLOP='K1305' WHERE MALOP='K13'

INSERT INTO dbo.KHOA (MAKHOA, TENKHOA, NGTLAP, TRGKHOA)
VALUES
    ('KHMT', 'Khoa hoc may tinh', '2005-06-07', NULL),
    ('HTTT', 'He thong thong tin', '2005-06-07', NULL),
    ('CNPM', 'Cong nghe phan mem', '2005-06-07', NULL),
    ('MTT', 'Mang va truyen thong', '2005-10-20', NULL),
    ('KTMT', 'Ky thuat may tinh', '2005-12-20', NULL)
UPDATE dbo.LOP SET MAKHOA='KHMT' WHERE MALOP='K11'
UPDATE dbo.LOP SET MAKHOA='CNPM' WHERE MALOP='K12'
UPDATE dbo.LOP SET MAKHOA='MTT' WHERE MALOP='K13'


INSERT INTO dbo.GIAOVIEN (MAGV, HOTEN, HOCVI, HOCHAM, GIOITINH, NGSINH, NGVL, HESO, MUCLUONG, MAKHOA)
VALUES
    ('GV01', 'Ho Thanh Son', 'PTS', 'GS', 'Nam', '1950-05-02', '2004-11-01', 5.00, 2250000, 'KHMT'),
    ('GV02', 'Tran Tam Thanh', 'TS', 'PGS', 'Nam', '1965-12-17', '2004-04-20', 4.50, 2025000, 'HTTT'),
    ('GV03', 'Do Nghiem Phung', 'TS', 'GS', 'Nu', '1950-08-22', '2004-09-23', 4.00, 1800000, 'CNPM'),
    ('GV04', 'Mai Thanh Danh', 'TS', 'PGS', 'Nam', '1961-12-22', '2005-12-01', 3.50, 1350000, 'KTMT'),
    ('GV05', 'Tran Doan Hung', 'TS', 'GV', 'Nam', '1953-11-13', '2005-12-01', 4.50, 2025000, 'KHMT'),
    ('GV06', 'Nguyen Minh Tien', 'THS', 'GV', 'Nam', '1971-11-23', '2005-01-03', 4.00, 1800000, 'KHMT'),
    ('GV07', 'Le Thi Tran', 'KS', NULL, 'Nu', '1974-03-26', '2005-01-03', 1.69, 760500, 'KHMT'),
    ('GV08', 'Nguyen To Lan', 'THS', 'GV', 'Nu', '1966-12-31', '2005-01-03', 4.00, 1800000, 'HTTT'),
    ('GV09', 'Le Tran Anh Loan', 'KS', NULL, 'Nu', '1972-07-17', '2005-01-03', 1.86, 837000, 'CNPM'),
    ('GV10', 'Ho Thanh Tung', 'CN', 'GV', 'Nam', '1980-01-29', '2005-05-15', 2.67, 1201500, 'MTT'),
    ('GV11', 'Tran Van Anh', 'CN', NULL, 'Nu', '1981-03-29', '2005-05-15', 1.69, 760500, 'CNPM'),
    ('GV12', 'Nguyen Linh Dan', 'CN', NULL, 'Nu', '1980-05-23', '2005-05-15', 1.69, 760500, 'KTMT'),
    ('GV13', 'Truong Minh Chau', 'THS', 'GV', 'Nu', '1976-11-30', '2005-05-15', 3.00, 1350000, 'MTT'),
    ('GV14', 'Le Ha Thanh', 'THS', 'GV', 'Nam', '1978-05-04', '2005-05-15', 3.00, 1350000, 'KHMT'),
    ('GV15', 'Hoang Van Nam', 'CN', NULL, 'Nam', '1982-07-12', '2005-05-15', 2.67, 1201500, 'MTT')

UPDATE dbo.KHOA SET TRGKHOA='GV01' WHERE MAKHOA='KHMT'
UPDATE dbo.KHOA SET TRGKHOA='GV02' WHERE MAKHOA='HTTT'
UPDATE dbo.KHOA SET TRGKHOA='GV04' WHERE MAKHOA='CNPM'
UPDATE dbo.KHOA SET TRGKHOA='GV03' WHERE MAKHOA='MTT'

INSERT INTO dbo.MONHOC (MAMH, TENMH, TCLT, TCTH, MAKHOA)
VALUES
    ('THDC', 'Tin hoc dai cuong', 4, 1, 'KHMT'),
    ('CTRR', 'Cau truc roi rac', 5, 0, 'KHMT'),
    ('CSDL', 'Co so du lieu', 3, 1, 'HTTT'),
    ('CTDLGT', 'Cau truc du lieu va giai thuat', 3, 1, 'HTTT'),
    ('PTTKTT', 'Phan tich thiet ke thuat toan', 3, 0, 'KHMT'),
    ('DHMT', 'Do hoa may tinh', 3, 0, 'KTMT'),
    ('KTMT', 'Kien truc may tinh', 3, 0, 'KTMT'),
    ('TKCSDL', 'Thiet ke co so du lieu', 3, 1, 'HTTT'),
    ('PTTKHTTT', 'Phan tich thiet ke he thong thong tin', 4, 1, 'HTTT'),
    ('HDH', 'He dieu hanh', 4, 0, 'KTMT'),
    ('NMCNPM', 'Nhap mon cong nghe phan mem', 3, 0, 'CNPM'),
    ('LTCFW', 'Lap trinh C for win', 3, 1, 'CNPM'),
    ('LTHDT', 'Lap trinh huong doi tuong', 3, 1, 'CNPM')
INSERT INTO dbo.KETQUATHI (MAHV, MAMH, LANTHI, NGTHI, DIEM, KQUA)
VALUES
    ('K1101', 'CSDL', 1, '2007-07-20', 10.00, 'Dat'),
    ('K1101', 'CTDLGT', 1, '2006-12-28', 9.00, 'Dat'),
    ('K1101', 'THDC', 1, '2005-05-20', 9.00, 'Dat'),
    ('K1101', 'CTRR', 1, '2005-05-13', 9.50, 'Dat'),
    ('K1102', 'CSDL', 1, '2007-07-20', 4.00, 'Khong Dat'),
    ('K1102', 'CSDL', 2, '2007-07-27', 4.25, 'Khong Dat'),
    ('K1102', 'CSDL', 3, '2006-08-10', 4.50, 'Khong Dat'),
    ('K1103', 'CSDL', 2, '2007-07-27', 8.25, 'Dat'),
    ('K1103', 'CTDLGT', 1, '2006-12-28', 7.00, 'Dat'),
    ('K1103', 'THDC', 1, '2005-05-20', 8.00, 'Dat'),
    ('K1103', 'CTRR', 1, '2005-05-13', 6.50, 'Dat'),
    ('K1104', 'CSDL', 1, '2007-07-20', 3.75, 'Khong Dat'),
    ('K1104', 'CTDLGT', 1, '2006-12-28', 4.00, 'Khong Dat'),
    ('K1104', 'THDC', 1, '2005-05-20', 4.00, 'Khong Dat'),
    ('K1104', 'CTRR', 1, '2005-05-13', 4.00, 'Khong Dat'),
    ('K1104', 'CTRR', 2, '2005-05-20', 3.50, 'Khong Dat'),
    ('K1104', 'CTRR', 3, '2006-06-30', 4.00, 'Khong Dat'),
    ('K1201', 'CSDL', 1, '2007-07-20', 6.00, 'Dat'),
    ('K1201', 'CTDLGT', 1, '2006-12-28', 5.00, 'Dat'),
    ('K1201', 'THDC', 1, '2005-05-20', 8.50, 'Dat'),
    ('K1201', 'CTRR', 1, '2005-05-13', 9.00, 'Dat'),
    ('K1202', 'CSDL', 1, '2007-07-20', 8.00, 'Dat'),
    ('K1202', 'CTDLGT', 1, '2006-12-28', 4.00, 'Khong Dat'),
    ('K1202', 'CTDLGT', 2, '2007-05-01', 5.00, 'Dat'),
    ('K1202', 'THDC', 1, '2006-05-20', 4.00, 'Khong Dat'),
    ('K1202', 'THDC', 2, '2006-05-27', 4.00, 'Khong Dat'),
    ('K1202', 'CTRR', 1, '2006-05-13', 3.00, 'Khong Dat'),
    ('K1202', 'CTRR', 2, '2006-05-20', 4.00, 'Khong Dat'),
    ('K1202', 'CTRR', 3, '2006-06-30', 6.25, 'Dat'),
    ('K1203', 'CSDL', 1, '2007-07-20', 9.25, 'Dat'),
    ('K1203', 'CTDLGT', 1, '2006-12-28', 9.50, 'Dat'),
    ('K1203', 'THDC', 1, '2005-05-20', 10.00, 'Dat'),
    ('K1203', 'CTRR', 1, '2005-05-13', 10.00, 'Dat'),
    ('K1204', 'CSDL', 1, '2007-07-20', 8.50, 'Dat'),
    ('K1204', 'CTDLGT', 1, '2006-12-28', 6.75, 'Dat'),
    ('K1204', 'THDC', 1, '2005-05-20', 4.00, 'Khong Dat'),
    ('K1204', 'CTRR', 1, '2005-05-13', 6.00, 'Dat'),
    ('K1301', 'CSDL', 1, '2006-12-20', 4.25, 'Khong Dat'),
    ('K1301', 'CTDLGT', 1, '2006-07-25', 8.00, 'Dat'),
    ('K1301', 'THDC', 1, '2006-05-20', 7.75, 'Dat'),
    ('K1301', 'CTRR', 1, '2006-05-13', 8.00, 'Dat'),
    ('K1302', 'CSDL', 1, '2006-12-20', 6.75, 'Dat'),
    ('K1302', 'CTDLGT', 1, '2006-07-25', 5.00, 'Dat'),
    ('K1302', 'THDC', 1, '2006-05-20', 8.00, 'Dat'),
    ('K1302', 'CTRR', 1, '2006-05-13', 8.50, 'Dat'),
    ('K1303', 'CSDL', 1, '2006-12-20', 4.00, 'Khong Dat'),
    ('K1303', 'CTDLGT', 1, '2006-07-25', 4.50, 'Khong Dat'),
    ('K1303', 'CTDLGT', 2, '2006-08-07', 4.00, 'Khong Dat'),
    ('K1303', 'CTDLGT', 3, '2006-08-15', 4.25, 'Khong Dat'),
    ('K1303', 'THDC', 1, '2006-05-20', 4.50, 'Khong Dat'),
    ('K1303', 'CTRR', 1, '2006-05-13', 3.25, 'Khong Dat'),
    ('K1303', 'CTRR', 2, '2006-05-20', 5.00, 'Dat'),
    ('K1304', 'CSDL', 1, '2006-12-20', 7.75, 'Dat'),
    ('K1304', 'CTDLGT', 1, '2006-07-25', 9.75, 'Dat'),
    ('K1304', 'THDC', 1, '2006-05-20', 5.50, 'Dat'),
    ('K1304', 'CTRR', 1, '2006-05-13', 5.00, 'Dat'),
    ('K1305', 'CSDL', 1, '2006-12-20', 9.25, 'Dat'),
    ('K1305', 'CTDLGT', 1, '2006-07-25', 10.00, 'Dat'),
    ('K1305', 'THDC', 1, '2006-05-20', 8.00, 'Dat'),
    ('K1305', 'CTRR', 1, '2006-05-13', 10.00, 'Dat')

INSERT INTO dbo.GIANGDAY (MALOP, MAMH, MAGV, HOCKY, NAM, TUNGAY, DENNGAY)
VALUES
    ('K11', 'THDC', 'GV07', 1, 2006, '2006-01-02', '2006-12-05'),
    ('K12', 'THDC', 'GV06', 1, 2006, '2006-01-02', '2006-12-05'),
    ('K13', 'THDC', 'GV15', 1, 2006, '2006-01-02', '2006-12-05'),
    ('K11', 'CTRR', 'GV02', 1, 2006, '2006-09-01', '2006-05-17'),
    ('K12', 'CTRR', 'GV02', 1, 2006, '2006-09-01', '2006-05-17'),
    ('K13', 'CTRR', 'GV08', 1, 2006, '2006-09-01', '2006-05-17'),
    ('K11', 'CSDL', 'GV05', 2, 2006, '2006-01-06', '2006-07-15'),
    ('K12', 'CSDL', 'GV09', 2, 2006, '2006-01-06', '2006-07-15'),
    ('K13', 'CTDLGT', 'GV15', 2, 2006, '2006-01-06', '2006-07-15'),
    ('K13', 'CSDL', 'GV05', 3, 2006, '2006-01-08', '2006-12-15'),
    ('K13', 'DHMT', 'GV07', 3, 2006, '2006-01-08', '2006-12-15'),
    ('K11', 'CTDLGT', 'GV15', 3, 2006, '2006-01-08', '2006-12-15'),
    ('K12', 'CTDLGT', 'GV15', 3, 2006, '2006-01-08', '2006-12-15'),
    ('K11', 'HDH', 'GV04', 1, 2007, '2007-02-01', '2007-02-18'),
    ('K12', 'HDH', 'GV04', 1, 2007, '2007-02-01', '2007-03-20'),
    ('K11', 'DHMT', 'GV07', 1, 2007, '2007-02-18', '2007-03-20')